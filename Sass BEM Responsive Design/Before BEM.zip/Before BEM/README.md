[VS Hotkeys](https://code.visualstudio.com/docs/getstarted/keybindings)

## Shift + Alt + F

